import React from "react";

const Logo = () => {
  return (
    <h1 className="text-white font-extrabold text-xl ml-[24px]">Solu Social</h1>
  );
};

export default Logo;
